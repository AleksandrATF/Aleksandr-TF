// правильно
let message = 'Hello';
let user ='Александр';
let id = 0;
// нерекомендуется
let newUser = 'Александр', newId = 0, newMessage = 'Hello peace';

let message;

message = 'Hello';

message = 'Innopolis';

alert(message);

console.log(message);

